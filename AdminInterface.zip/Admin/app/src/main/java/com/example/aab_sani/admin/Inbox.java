package com.example.aab_sani.admin;

public class Inbox {

    public String sender_name, restaurant_name;

    public Inbox (String sender_name, String restaurant_name) {
        this.sender_name = sender_name;
        this.restaurant_name = restaurant_name;
    }
}
